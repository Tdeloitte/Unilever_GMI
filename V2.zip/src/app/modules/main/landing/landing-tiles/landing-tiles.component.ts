import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-tiles',
  templateUrl: './landing-tiles.component.html',
  styleUrls: ['./landing-tiles.component.scss']
})
export class LandingTilesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
